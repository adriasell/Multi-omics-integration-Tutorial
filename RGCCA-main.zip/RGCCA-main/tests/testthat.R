library(testthat)
library(RGCCA)

test_check("RGCCA")
